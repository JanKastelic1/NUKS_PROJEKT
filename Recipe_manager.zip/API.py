import os
import json
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

DATABASE = 'recipes.db'
STATIC_DIR = 'static'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

class RequestHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        parsed_path = urlparse(self.path)
        if self.path == '/':
            self.serve_index()
        elif self.path.startswith('/static/'):
            self.serve_static(parsed_path.path[1:])
        elif self.path == '/recipes':
            self.get_recipes()
        else:
            self.send_error(404, "File not found")

    def serve_index(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        with open('FR.html', 'rb') as file:
            self.wfile.write(file.read())

    def serve_static(self, path):
        try:
            with open(path, 'rb') as file:
                self.send_response(200)
                if path.endswith('.css'):
                    self.send_header('Content-type', 'text/css')
                elif path.endswith('.png') or path.endswith('.jpg') or path.endswith('.jpeg'):
                    self.send_header('Content-type', 'image/jpeg')
                self.end_headers()
                self.wfile.write(file.read())
        except FileNotFoundError:
            self.send_error(404, "File not found")

    def get_recipes(self):
        conn = get_db_connection()
        recipes = conn.execute('SELECT * FROM recipes').fetchall()
        conn.close()
        recipes_list = [dict(id=row['id'], title=row['title'], ingredients=row['ingredients'], instructions=row['instructions']) for row in recipes]
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(recipes_list).encode())

    def do_POST(self):
        parsed_path = urlparse(self.path)
        if parsed_path.path == '/recipes':
            self.add_recipe()
        else:
            self.send_error(404, "File not found")

    def add_recipe(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        params = parse_qs(post_data)

        title = params.get('title')[0]
        ingredients = params.get('ingredients')[0]
        instructions = params.get('instructions')[0]

        conn = get_db_connection()
        conn.execute('INSERT INTO recipes (title, ingredients, instructions) VALUES (?, ?, ?)',
                     (title, ingredients, instructions))
        conn.commit()
        conn.close()
        self.send_response(201)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps({'status': 'Recipe added'}).encode())

    def do_DELETE(self):
        parsed_path = urlparse(self.path)
        if parsed_path.path.startswith('/recipes/'):
            recipe_id = int(parsed_path.path.split('/')[-1])
            self.delete_recipe(recipe_id)
        else:
            self.send_error(404, "File not found")

    def delete_recipe(self, recipe_id):
        conn = get_db_connection()
        conn.execute('DELETE FROM recipes WHERE id = ?', (recipe_id,))
        conn.commit()
        conn.close()
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps({'status': 'Recipe deleted'}).encode())

def run(server_class=HTTPServer, handler_class=RequestHandler, port=8000):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Starting server on port {port}...')
    httpd.serve_forever()

if __name__ == '__main__':
    run()
