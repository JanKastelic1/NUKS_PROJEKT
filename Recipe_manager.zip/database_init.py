import sqlite3

DATABASE = 'recipes.db'

def create_db():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('''
              CREATE TABLE recipes (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  title TEXT NOT NULL,
                  ingredients TEXT NOT NULL,
                  instructions TEXT NOT NULL
              )
              ''')
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_db()
    print("Database initialized successfully.")
